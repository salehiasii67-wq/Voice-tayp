/**
 * Core domain types for the Voice Journal feature.
 * Keep this file provider-agnostic: no browser SpeechRecognition types,
 * no translation-vendor types. Those live behind the service interfaces
 * in src/services/.
 */

export type RecordingState =
  | 'idle'
  | 'listening'
  | 'paused'
  | 'processing'
  | 'error';

export type TranslationStatus =
  | 'none'
  | 'pending'
  | 'partial'
  | 'complete'
  | 'error';

/** A single recognized chunk of speech, before it's merged into the transcript. */
export interface TranscriptSegment {
  id: string;
  text: string;
  isFinal: boolean;
  timestamp: number;
  /** Confidence score from the recognition engine, 0-1, if provided. */
  confidence?: number;
}

/** One finalized, translatable unit of the transcript (roughly a sentence/utterance). */
export interface TranscriptBlock {
  id: string;
  persianText: string;
  englishText: string | null;
  translationStatus: TranslationStatus;
  createdAt: number;
}

export interface VoiceRecognitionError {
  code:
    | 'not-supported'
    | 'permission-denied'
    | 'no-speech'
    | 'network'
    | 'aborted'
    | 'unknown';
  message: string;
  raw?: unknown;
}

export interface TranslationError {
  code: 'not-configured' | 'network' | 'timeout' | 'invalid-response' | 'unknown';
  message: string;
  raw?: unknown;
}

/** Persisted entity — see src/db/schema.ts for the Dexie table definition. */
export interface VoiceJournalSession {
  id: string;
  title: string;
  persianText: string;
  englishText: string;
  blocks: TranscriptBlock[];
  createdAt: number;
  updatedAt: number;
  /** Total recorded duration in seconds, accumulated across pause/resume. */
  duration: number;
  wordCount: number;
  language: 'fa-IR';
  translationStatus: TranslationStatus;
  tags: string[];
  notes: string;
  /** Optional link to an existing TraderMind OS entity (trade, review, etc.) */
  linkedEntity?: {
    type: 'trade' | 'strategy' | 'review' | 'note';
    id: string;
  };
}

export interface TextStatistics {
  wordCount: number;
  characterCount: number;
  sentenceCount: number;
  durationSeconds: number;
}
