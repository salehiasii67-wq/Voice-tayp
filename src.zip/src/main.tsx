import React from 'react';
import ReactDOM from 'react-dom/client';
import { VoiceJournal } from '@/components/voice-journal/VoiceJournal';
import './index.css';

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <VoiceJournal />
  </React.StrictMode>
);
