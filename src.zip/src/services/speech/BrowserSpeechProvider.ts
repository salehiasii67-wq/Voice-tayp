import type {
  SpeechRecognitionProvider,
  SpeechRecognitionOptions,
  ProviderState,
} from './SpeechRecognitionProvider';
import type { TranscriptSegment, VoiceRecognitionError } from '@/types/voice-journal';

/**
 * Minimal ambient types for the (non-standard, vendor-prefixed) Web Speech
 * API. Not all browsers implement this; isSupported reflects that.
 */
interface WebSpeechRecognition extends EventTarget {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  maxAlternatives: number;
  start(): void;
  stop(): void;
  abort(): void;
  onresult: ((event: WebSpeechRecognitionEvent) => void) | null;
  onerror: ((event: WebSpeechRecognitionErrorEvent) => void) | null;
  onend: (() => void) | null;
  onstart: (() => void) | null;
}

interface WebSpeechRecognitionEvent {
  resultIndex: number;
  results: WebSpeechRecognitionResultList;
}
interface WebSpeechRecognitionResultList {
  length: number;
  [index: number]: WebSpeechRecognitionResult;
}
interface WebSpeechRecognitionResult {
  isFinal: boolean;
  length: number;
  [index: number]: { transcript: string; confidence: number };
}
interface WebSpeechRecognitionErrorEvent {
  error: string;
  message?: string;
}

type WebSpeechRecognitionConstructor = new () => WebSpeechRecognition;

function getRecognitionConstructor(): WebSpeechRecognitionConstructor | null {
  const w = window as unknown as {
    SpeechRecognition?: WebSpeechRecognitionConstructor;
    webkitSpeechRecognition?: WebSpeechRecognitionConstructor;
  };
  return w.SpeechRecognition ?? w.webkitSpeechRecognition ?? null;
}

/**
 * BrowserSpeechProvider
 * ----------------------
 * Wraps the browser's built-in SpeechRecognition API.
 *
 * Key behavior that makes "pause/resume without duplicating or losing text"
 * work: the browser API has no native pause. Under the hood, "pause" fully
 * stops the underlying recognizer, and "resume" starts a *new* recognition
 * session. Because each session's results array is scoped to that session
 * only, restarting never replays earlier final results — so the caller
 * (useSpeechRecognition) is safe to just keep appending onSegment events
 * to its own accumulated transcript across multiple start/stop cycles.
 *
 * The provider also auto-restarts on a silent 'onend' (which browsers fire
 * periodically even mid-conversation on some platforms) as long as the
 * caller hasn't explicitly stopped/paused — this is what makes "continuous"
 * dictation actually continuous in practice.
 */
export class BrowserSpeechProvider implements SpeechRecognitionProvider {
  private recognition: WebSpeechRecognition | null = null;
  private options: SpeechRecognitionOptions | null = null;
  private segmentCallback: ((segment: TranscriptSegment) => void) | null = null;
  private errorCallback: ((error: VoiceRecognitionError) => void) | null = null;
  private stateCallback: ((state: ProviderState) => void) | null = null;
  private explicitlyStopped = true;
  private currentState: ProviderState = 'idle';
  private segmentCounter = 0;

  get isSupported(): boolean {
    return getRecognitionConstructor() !== null;
  }

  onSegment(callback: (segment: TranscriptSegment) => void): void {
    this.segmentCallback = callback;
  }

  onError(callback: (error: VoiceRecognitionError) => void): void {
    this.errorCallback = callback;
  }

  onStateChange(callback: (state: ProviderState) => void): void {
    this.stateCallback = callback;
  }

  start(options: SpeechRecognitionOptions): void {
    if (!this.isSupported) {
      this.emitError({
        code: 'not-supported',
        message: 'مرورگر شما از تشخیص گفتار پشتیبانی نمی‌کند.',
      });
      return;
    }
    this.options = options;
    this.explicitlyStopped = false;
    this.launchSession();
  }

  private launchSession(): void {
    const Ctor = getRecognitionConstructor();
    if (!Ctor || !this.options) return;

    const recognition = new Ctor();
    recognition.lang = this.options.language;
    recognition.continuous = this.options.continuous;
    recognition.interimResults = this.options.interimResults;
    recognition.maxAlternatives = 1;

    recognition.onstart = () => {
      this.setState('listening');
    };

    recognition.onresult = (event) => {
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const result = event.results[i];
        const alt = result[0];
        if (!alt) continue;
        this.segmentCounter += 1;
        const segment: TranscriptSegment = {
          id: `seg-${Date.now()}-${this.segmentCounter}`,
          text: alt.transcript,
          isFinal: result.isFinal,
          timestamp: Date.now(),
          confidence: alt.confidence,
        };
        this.segmentCallback?.(segment);
      }
    };

    recognition.onerror = (event) => {
      const mapped = this.mapError(event.error);
      // 'no-speech' is routine (user paused mid-thought) — don't surface
      // it as a hard error, just let onend decide whether to restart.
      if (mapped.code !== 'no-speech') {
        this.emitError(mapped);
      }
    };

    recognition.onend = () => {
      if (this.explicitlyStopped) {
        this.setState('idle');
        return;
      }
      // Browser ended the session on its own (common on long continuous
      // sessions) — restart transparently so dictation feels unbroken.
      this.setState('processing');
      try {
        this.launchSession();
      } catch {
        this.setState('error');
      }
    };

    this.recognition = recognition;
    try {
      recognition.start();
    } catch {
      // start() throws if called while already running; safe to ignore,
      // the existing session continues.
    }
  }

  stop(): void {
    this.explicitlyStopped = true;
    this.recognition?.stop();
    this.setState('idle');
  }

  pause(): void {
    // No native pause — stop the underlying session but remember we're
    // "paused" rather than "idle" so resume() knows to relaunch.
    this.explicitlyStopped = true;
    this.recognition?.stop();
    this.setState('paused');
  }

  resume(): void {
    if (!this.options) return;
    this.explicitlyStopped = false;
    this.launchSession();
  }

  destroy(): void {
    this.explicitlyStopped = true;
    this.recognition?.abort();
    this.recognition = null;
    this.segmentCallback = null;
    this.errorCallback = null;
    this.stateCallback = null;
  }

  private setState(state: ProviderState): void {
    this.currentState = state;
    this.stateCallback?.(state);
  }

  private emitError(error: VoiceRecognitionError): void {
    this.setState('error');
    this.errorCallback?.(error);
  }

  private mapError(code: string): VoiceRecognitionError {
    switch (code) {
      case 'not-allowed':
      case 'permission-denied':
        return {
          code: 'permission-denied',
          message: 'دسترسی به میکروفون رد شد. لطفاً مجوز میکروفون را در تنظیمات مرورگر فعال کنید.',
          raw: code,
        };
      case 'no-speech':
        return { code: 'no-speech', message: 'صدایی شناسایی نشد.', raw: code };
      case 'network':
        return {
          code: 'network',
          message: 'خطای شبکه در تشخیص گفتار. اتصال اینترنت را بررسی کنید.',
          raw: code,
        };
      case 'aborted':
        return { code: 'aborted', message: 'ضبط متوقف شد.', raw: code };
      default:
        return {
          code: 'unknown',
          message: 'خطای ناشناخته در تشخیص گفتار رخ داد.',
          raw: code,
        };
    }
  }
}
