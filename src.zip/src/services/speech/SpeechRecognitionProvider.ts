import type { TranscriptSegment, VoiceRecognitionError } from '@/types/voice-journal';

/**
 * Provider-agnostic contract for a speech recognition engine.
 *
 * The UI and hooks never talk to the browser SpeechRecognition API (or any
 * vendor SDK) directly — they talk to this interface. Swapping in Whisper,
 * Google Speech-to-Text, Azure, or Deepgram later means writing one new
 * class that implements this interface; nothing else in the app changes.
 */
export interface SpeechRecognitionProvider {
  readonly isSupported: boolean;

  start(options: SpeechRecognitionOptions): void;
  stop(): void;
  pause(): void;
  resume(): void;

  onSegment(callback: (segment: TranscriptSegment) => void): void;
  onError(callback: (error: VoiceRecognitionError) => void): void;
  onStateChange(callback: (state: ProviderState) => void): void;

  /** Release listeners/resources. Call on unmount. */
  destroy(): void;
}

export interface SpeechRecognitionOptions {
  language: string; // e.g. 'fa-IR'
  continuous: boolean;
  interimResults: boolean;
}

export type ProviderState = 'idle' | 'listening' | 'paused' | 'processing' | 'error';
