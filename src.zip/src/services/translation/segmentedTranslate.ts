import type { TranslationService } from './TranslationService';
import type { TranscriptBlock, TranslationError } from '@/types/voice-journal';

/**
 * Translates only the blocks that need it (status 'none' or 'error'),
 * leaving already-translated blocks untouched. This is what "segmented
 * translation" means here: each finalized Persian sentence/utterance is
 * its own block, translated once, independently — never the whole
 * document re-sent on every update.
 *
 * Returns a new array (does not mutate input) so it's safe to use directly
 * as a Zustand state update.
 */
export async function translatePendingBlocks(
  blocks: TranscriptBlock[],
  service: TranslationService,
  onBlockUpdate?: (updatedBlock: TranscriptBlock) => void
): Promise<TranscriptBlock[]> {
  if (!service.isConfigured) {
    return blocks.map((b) =>
      b.translationStatus === 'none' || b.translationStatus === 'error'
        ? { ...b, translationStatus: 'error' as const }
        : b
    );
  }

  const result: TranscriptBlock[] = [];
  for (const block of blocks) {
    if (
      block.translationStatus !== 'none' &&
      block.translationStatus !== 'error'
    ) {
      result.push(block);
      continue;
    }
    if (!block.persianText.trim()) {
      result.push({ ...block, translationStatus: 'complete', englishText: '' });
      continue;
    }
    try {
      const englishText = await service.translate(block.persianText, 'fa', 'en');
      const updated: TranscriptBlock = {
        ...block,
        englishText,
        translationStatus: 'complete',
      };
      result.push(updated);
      onBlockUpdate?.(updated);
    } catch (raw) {
      const err = raw as TranslationError;
      const updated: TranscriptBlock = {
        ...block,
        translationStatus: 'error',
        englishText: block.englishText,
      };
      result.push(updated);
      onBlockUpdate?.(updated);
      // Surface but don't abort the whole batch — other blocks may still
      // succeed (e.g. transient timeout on one segment).
      if (err?.code === 'not-configured') {
        // No point retrying remaining blocks against an unconfigured
        // service; mark the rest as error too and stop calling out.
        const restIndex = blocks.indexOf(block) + 1;
        for (let i = restIndex; i < blocks.length; i++) {
          const rest = blocks[i];
          if (rest.translationStatus === 'none') {
            result.push({ ...rest, translationStatus: 'error' });
          } else {
            result.push(rest);
          }
        }
        return result;
      }
    }
  }
  return result;
}
