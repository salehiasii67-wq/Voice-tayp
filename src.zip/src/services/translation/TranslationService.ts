import type { TranslationError } from '@/types/voice-journal';

/**
 * Provider-agnostic translation contract. Swap OpenAI / Google Translate /
 * Azure / DeepL by implementing this interface — nothing else changes.
 *
 * SECURITY: implementations must never hold a secret API key in frontend
 * code. Real providers call a same-origin backend route (e.g. POST
 * /api/translate) that holds the key server-side. See
 * BackendTranslationService below for the expected shape.
 */
export interface TranslationService {
  readonly isConfigured: boolean;
  translate(text: string, from: string, to: string): Promise<string>;
}

/**
 * Fallback used when no backend translation route is configured.
 * Keeps the rest of the app fully functional (Persian transcription,
 * saving, export) — translation calls just resolve to a clear
 * "not configured" state instead of throwing an opaque error.
 */
export class NullTranslationService implements TranslationService {
  readonly isConfigured = false;

  async translate(): Promise<string> {
    const error: TranslationError = {
      code: 'not-configured',
      message:
        'سرویس ترجمه پیکربندی نشده است. برای فعال‌سازی ترجمه، یک مسیر بک‌اند امن (مثل /api/translate) با کلید API متصل کنید.',
    };
    throw error;
  }
}

/**
 * Calls a same-origin backend endpoint that itself calls the real
 * translation provider (OpenAI, Google Translate, etc.) with a
 * server-side-only API key. This is the pattern to use in production —
 * point `endpoint` at whatever route TraderMind OS's backend exposes.
 */
export class BackendTranslationService implements TranslationService {
  readonly isConfigured = true;

  constructor(private readonly endpoint: string = '/api/translate') {}

  async translate(text: string, from: string, to: string): Promise<string> {
    let response: Response;
    try {
      response = await fetch(this.endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text, from, to }),
      });
    } catch (raw) {
      const error: TranslationError = {
        code: 'network',
        message: 'خطای شبکه هنگام ترجمه رخ داد.',
        raw,
      };
      throw error;
    }

    if (!response.ok) {
      const error: TranslationError = {
        code: response.status === 408 ? 'timeout' : 'unknown',
        message: `سرویس ترجمه با خطا مواجه شد (${response.status}).`,
      };
      throw error;
    }

    let data: unknown;
    try {
      data = await response.json();
    } catch (raw) {
      const error: TranslationError = {
        code: 'invalid-response',
        message: 'پاسخ نامعتبر از سرویس ترجمه دریافت شد.',
        raw,
      };
      throw error;
    }

    const translated = (data as { translatedText?: string }).translatedText;
    if (typeof translated !== 'string') {
      const error: TranslationError = {
        code: 'invalid-response',
        message: 'پاسخ سرویس ترجمه فاقد متن ترجمه‌شده بود.',
      };
      throw error;
    }
    return translated;
  }
}

/**
 * Chooses the active provider. In this standalone build there is no
 * backend, so it defaults to NullTranslationService. When wiring into
 * TraderMind OS, replace this with a check against real config (env var,
 * feature flag, etc.) and return BackendTranslationService when ready.
 */
export function createTranslationService(): TranslationService {
  return new NullTranslationService();
}
