import { saveAs } from 'file-saver';
import {
  Document,
  Packer,
  Paragraph,
  TextRun,
  HeadingLevel,
  AlignmentType,
} from 'docx';
import * as XLSX from 'xlsx';
import type { VoiceJournalSession } from '@/types/voice-journal';
import { formatDuration } from '@/utils/textStatistics';

function formatDate(ts: number): string {
  return new Date(ts).toLocaleDateString('fa-IR');
}
function formatTime(ts: number): string {
  return new Date(ts).toLocaleTimeString('fa-IR');
}

export function exportAsPlainText(session: VoiceJournalSession): void {
  const lines = [
    session.title,
    formatDate(session.createdAt),
    '',
    '--- متن فارسی ---',
    session.persianText,
    '',
    '--- ترجمه انگلیسی ---',
    session.englishText || '(ترجمه‌ای موجود نیست)',
  ];
  const blob = new Blob([lines.join('\n')], { type: 'text/plain;charset=utf-8' });
  saveAs(blob, `${session.title || 'voice-journal'}.txt`);
}

export function exportAsMarkdown(session: VoiceJournalSession): void {
  const md = [
    `# ${session.title}`,
    '',
    `**تاریخ:** ${formatDate(session.createdAt)}  `,
    `**مدت زمان:** ${formatDuration(session.duration)}  `,
    `**تعداد کلمات:** ${session.wordCount}`,
    '',
    '## متن فارسی',
    '',
    session.persianText,
    '',
    '## ترجمه انگلیسی',
    '',
    session.englishText || '_ترجمه‌ای موجود نیست._',
  ].join('\n');
  const blob = new Blob([md], { type: 'text/markdown;charset=utf-8' });
  saveAs(blob, `${session.title || 'voice-journal'}.md`);
}

export async function exportAsDocx(session: VoiceJournalSession): Promise<void> {
  const doc = new Document({
    sections: [
      {
        children: [
          new Paragraph({
            text: session.title,
            heading: HeadingLevel.TITLE,
          }),
          new Paragraph({
            children: [
              new TextRun({
                text: `${formatDate(session.createdAt)} — مدت زمان: ${formatDuration(
                  session.duration
                )} — تعداد کلمات: ${session.wordCount}`,
                italics: true,
              }),
            ],
          }),
          new Paragraph({ text: '' }),
          new Paragraph({ text: 'متن فارسی', heading: HeadingLevel.HEADING_1 }),
          new Paragraph({
            alignment: AlignmentType.RIGHT,
            bidirectional: true,
            children: [new TextRun({ text: session.persianText, rightToLeft: true })],
          }),
          new Paragraph({ text: '' }),
          new Paragraph({ text: 'English Translation', heading: HeadingLevel.HEADING_1 }),
          new Paragraph({
            children: [
              new TextRun({
                text: session.englishText || '(No translation available)',
              }),
            ],
          }),
        ],
      },
    ],
  });

  const blob = await Packer.toBlob(doc);
  saveAs(blob, `${session.title || 'voice-journal'}.docx`);
}

export function exportAsXlsx(session: VoiceJournalSession): void {
  const rows = [
    {
      Date: formatDate(session.createdAt),
      Time: formatTime(session.createdAt),
      'Persian Text': session.persianText,
      'English Translation': session.englishText || '',
      'Duration (s)': session.duration,
      'Word Count': session.wordCount,
    },
  ];
  const worksheet = XLSX.utils.json_to_sheet(rows);
  worksheet['!cols'] = [
    { wch: 12 },
    { wch: 12 },
    { wch: 60 },
    { wch: 60 },
    { wch: 12 },
    { wch: 12 },
  ];
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Voice Journal');
  XLSX.writeFile(workbook, `${session.title || 'voice-journal'}.xlsx`);
}

export type ExportFormat = 'txt' | 'md' | 'docx' | 'xlsx';

export async function exportSession(
  session: VoiceJournalSession,
  format: ExportFormat
): Promise<void> {
  switch (format) {
    case 'txt':
      return exportAsPlainText(session);
    case 'md':
      return exportAsMarkdown(session);
    case 'docx':
      return exportAsDocx(session);
    case 'xlsx':
      return exportAsXlsx(session);
  }
}
