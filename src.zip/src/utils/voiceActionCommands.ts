/**
 * Action-triggering voice commands (as opposed to punctuation commands,
 * which only replace text — see persianVoiceCommands.ts).
 *
 * This is a pure registry/matcher. It has no knowledge of Zustand, Dexie,
 * or React — the consuming hook/component supplies handlers and decides
 * what "save the journal" or "start a new trade entry" actually does.
 * That keeps this module trivially extensible: add a phrase + id here,
 * wire a handler where the feature lives.
 */

export type VoiceActionId =
  | 'new-trade-entry'
  | 'add-note'
  | 'save-journal'
  | 'translate'
  | 'clear-text'
  | 'start-recording'
  | 'stop-recording';

export interface VoiceActionCommand {
  id: VoiceActionId;
  /** Persian trigger phrases. Match is case-insensitive, whitespace-trimmed. */
  phrases: string[];
  description: string;
}

export const DEFAULT_ACTION_COMMANDS: VoiceActionCommand[] = [
  {
    id: 'new-trade-entry',
    phrases: ['ثبت معامله جدید'],
    description: 'Open/prepare a new trade journal entry',
  },
  {
    id: 'add-note',
    phrases: ['افزودن یادداشت'],
    description: 'Add a note to the current session',
  },
  {
    id: 'save-journal',
    phrases: ['ذخیره ژورنال'],
    description: 'Save the current voice journal session',
  },
  {
    id: 'translate',
    phrases: ['ترجمه کن'],
    description: 'Translate the Persian transcript to English',
  },
  {
    id: 'clear-text',
    phrases: ['پاک کردن متن'],
    description: 'Clear the current transcription',
  },
  {
    id: 'start-recording',
    phrases: ['شروع ضبط'],
    description: 'Start voice recording',
  },
  {
    id: 'stop-recording',
    phrases: ['توقف ضبط'],
    description: 'Stop voice recording',
  },
];

/**
 * Checks whether a finalized utterance matches a registered action command.
 * Returns the matched command, or null if no match. Only matches when the
 * command phrase is essentially the whole utterance (trimmed) — this avoids
 * firing "save the journal" just because those words appear mid-sentence
 * inside normal dictation.
 */
export function matchVoiceActionCommand(
  utterance: string,
  commands: VoiceActionCommand[] = DEFAULT_ACTION_COMMANDS
): VoiceActionCommand | null {
  const normalized = utterance.trim().replace(/[.!?؟،؛]+$/g, '').trim();
  if (!normalized) return null;

  for (const command of commands) {
    if (command.phrases.some((phrase) => phrase.trim() === normalized)) {
      return command;
    }
  }
  return null;
}

/** Handler map the UI/hook layer provides; kept separate from the registry itself. */
export type VoiceActionHandlers = Partial<
  Record<VoiceActionId, () => void | Promise<void>>
>;

export async function dispatchVoiceAction(
  command: VoiceActionCommand,
  handlers: VoiceActionHandlers
): Promise<boolean> {
  const handler = handlers[command.id];
  if (!handler) return false;
  await handler();
  return true;
}
