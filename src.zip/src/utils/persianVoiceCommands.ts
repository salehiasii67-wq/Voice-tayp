/**
 * parseVoiceCommands
 * ------------------
 * Converts spoken Persian punctuation commands ("نقطه", "ویرگول", ...) into
 * their literal punctuation marks. Pure function, no side effects, so it can
 * be unit tested and reused outside the speech pipeline (e.g. to clean up
 * text pasted from elsewhere).
 *
 * Design notes:
 * - Matching is done on word boundaries within the Persian text, using a
 *   zero-width-safe boundary check (Persian has no \b support in all
 *   engines the way Latin does, so we match on whitespace/punctuation
 *   context instead of relying on \b).
 * - Longer phrases ("علامت سؤال") are matched before shorter ones ("سؤال")
 *   so multi-word commands aren't partially consumed by a shorter rule.
 * - A command is only replaced when it appears as a standalone trailing
 *   phrase — i.e. preceded by whitespace/start-of-string and followed by
 *   whitespace/end-of-string/another command. This avoids clobbering the
 *   word if it's genuinely part of the sentence (e.g. "روی خط تیره ایستاد"
 *   where "خط" is being used as a real word in context — see caveats below).
 */

export interface VoiceCommandRule {
  /** Persian phrase(s) that trigger this rule. Longest-first ordering matters. */
  phrases: string[];
  /** Literal replacement. Use '\n' for newline, '\n\n' for paragraph break. */
  replacement: string;
  /** Human-readable id for extensibility / debugging / future custom commands. */
  id: string;
}

// Ordered so multi-word phrases are checked before their shorter substrings.
export const DEFAULT_PUNCTUATION_RULES: VoiceCommandRule[] = [
  { id: 'question-mark-1', phrases: ['علامت سؤال'], replacement: '؟' },
  { id: 'question-mark-2', phrases: ['علامت سوال'], replacement: '؟' },
  { id: 'exclamation-mark', phrases: ['علامت تعجب'], replacement: '!' },
  { id: 'quote-mark', phrases: ['علامت نقل قول'], replacement: '"' },
  { id: 'semicolon', phrases: ['نقطه ویرگول'], replacement: '؛' },
  { id: 'paragraph-break', phrases: ['پاراگراف جدید'], replacement: '\n\n' },
  { id: 'newline', phrases: ['خط جدید'], replacement: '\n' },
  { id: 'bracket-open', phrases: ['کروشه باز'], replacement: '[' },
  { id: 'bracket-close', phrases: ['کروشه بسته'], replacement: ']' },
  { id: 'paren-open', phrases: ['پرانتز باز'], replacement: '(' },
  { id: 'paren-close', phrases: ['پرانتز بسته'], replacement: ')' },
  { id: 'colon', phrases: ['دو نقطه'], replacement: ':' },
  { id: 'dash', phrases: ['خط تیره'], replacement: '-' },
  { id: 'slash', phrases: ['اسلش'], replacement: '/' },
  { id: 'comma', phrases: ['ویرگول'], replacement: '،' },
  { id: 'period', phrases: ['نقطه'], replacement: '.' },
];

/**
 * Builds a matcher for a single phrase that requires the phrase to be
 * bounded by whitespace / string edges — not embedded inside a longer word.
 */
function buildPhraseRegex(phrase: string): RegExp {
  const escaped = phrase.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  // (^|\s) ... (\s|$) — bounded on both sides so we don't match substrings
  // inside unrelated words. Captures the boundaries so we can restore them.
  return new RegExp(`(^|\\s)(${escaped})(?=\\s|$)`, 'gu');
}

/**
 * Parses spoken punctuation commands in `text` and returns the text with
 * commands replaced by their punctuation marks.
 *
 * Trailing space cleanup: after inserting punctuation, we remove the space
 * that preceded it (Persian punctuation typically attaches to the word
 * before it, e.g. "سلام." not "سلام .").
 */
export function parseVoiceCommands(
  text: string,
  rules: VoiceCommandRule[] = DEFAULT_PUNCTUATION_RULES
): string {
  let result = text;

  for (const rule of rules) {
    // Longest phrase-string first within a rule's own phrase list too.
    const orderedPhrases = [...rule.phrases].sort((a, b) => b.length - a.length);
    for (const phrase of orderedPhrases) {
      const regex = buildPhraseRegex(phrase);
      result = result.replace(regex, (_match, leadingSpace: string) => {
        if (rule.replacement === '\n' || rule.replacement === '\n\n') {
          // Newline commands: keep a single space-equivalent break, no
          // dangling space before it.
          return rule.replacement;
        }
        // Attach punctuation directly to preceding text, drop the space
        // that separated the spoken command from the prior word.
        return leadingSpace === '' ? rule.replacement : rule.replacement;
      });
    }
  }

  // Collapse any accidental double spaces left behind, but preserve
  // intentional newlines/paragraph breaks.
  result = result
    .split('\n')
    .map((line) => line.replace(/[ \t]{2,}/g, ' ').trim())
    .join('\n');

  return result;
}

/**
 * Returns true if the given trailing words of a live (in-progress) utterance
 * match a known command phrase — used by the streaming pipeline to decide
 * whether to apply parseVoiceCommands to the tail of interim text in
 * real time, without reprocessing the whole transcript on every tick.
 */
export function endsWithCommandPhrase(
  text: string,
  rules: VoiceCommandRule[] = DEFAULT_PUNCTUATION_RULES
): boolean {
  const trimmed = text.trim();
  if (!trimmed) return false;
  return rules.some((rule) =>
    rule.phrases.some((phrase) => trimmed.endsWith(phrase))
  );
}
