import type { TextStatistics } from '@/types/voice-journal';

/**
 * Word/character/sentence counting that works reasonably for both Persian
 * (space-delimited, same as Latin scripts for word-splitting purposes) and
 * English text.
 */
export function computeTextStatistics(
  text: string,
  durationSeconds: number
): TextStatistics {
  const trimmed = text.trim();
  const words = trimmed.length === 0 ? [] : trimmed.split(/\s+/);
  const sentences =
    trimmed.length === 0
      ? []
      : trimmed.split(/[.!?؟؛]+/).filter((s) => s.trim().length > 0);

  return {
    wordCount: words.length,
    characterCount: trimmed.length,
    sentenceCount: sentences.length,
    durationSeconds,
  };
}

export function formatDuration(totalSeconds: number): string {
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = Math.floor(totalSeconds % 60);
  return `${minutes}:${seconds.toString().padStart(2, '0')}`;
}
