import { useEffect, useRef, useState } from 'react';
import { ChevronDown, ChevronUp, Copy, Languages, Loader2, Search } from 'lucide-react';
import type { TranscriptBlock } from '@/types/voice-journal';
import { computeTextStatistics } from '@/utils/textStatistics';

interface BilingualEditorProps {
  blocks: TranscriptBlock[];
  /** Called on blur with the full edited Persian text, reconciled by the caller. */
  onCommitPersian: (fullText: string) => void;
  /** Called on blur with the full edited English text, reconciled by the caller. */
  onCommitEnglish: (fullText: string) => void;
  onTranslateAll: () => void;
  isTranslating: boolean;
  translationConfigured: boolean;
  durationSeconds: number;
}

type Panel = 'fa' | 'en';

/**
 * Blocks are the unit of translation/segmentation (see segmentedTranslate.ts)
 * but NOT the unit of editing. Mapping a multi-line textarea back onto
 * per-block text by line-index is fragile: an inserted or deleted newline,
 * or a block whose own text contains "\n" from punctuation commands
 * (خط جدید / پاراگراف جدید), immediately desyncs the index mapping and
 * silently misattributes text between blocks.
 *
 * Instead, each panel keeps its own local, freely-editable string while the
 * user types (so typing feels instant and never fights block boundaries),
 * and only reconciles back into the parent's block model on blur — at which
 * point the parent owns how to re-derive blocks from the flat text.
 */
export function BilingualEditor({
  blocks,
  onCommitPersian,
  onCommitEnglish,
  onTranslateAll,
  isTranslating,
  translationConfigured,
  durationSeconds,
}: BilingualEditorProps) {
  const [activePanel, setActivePanel] = useState<Panel>('fa');
  const [searchTerm, setSearchTerm] = useState('');
  const [matchIndex, setMatchIndex] = useState(0);

  const persianRef = useRef<HTMLTextAreaElement>(null);
  const englishRef = useRef<HTMLTextAreaElement>(null);

  const derivedPersianText = blocks.map((b) => b.persianText).join('\n');
  const derivedEnglishText = blocks.map((b) => b.englishText ?? '').join('\n');

  const [persianDraft, setPersianDraft] = useState(derivedPersianText);
  const [englishDraft, setEnglishDraft] = useState(derivedEnglishText);

  // Re-sync local drafts when blocks change from outside this component
  // (new dictation arriving, a session load, a translation completing) —
  // but not on every keystroke, since these effects only fire when the
  // *derived* text itself changes, not when the draft does.
  useEffect(() => {
    setPersianDraft(derivedPersianText);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [derivedPersianText]);
  useEffect(() => {
    setEnglishDraft(derivedEnglishText);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [derivedEnglishText]);

  const stats = computeTextStatistics(persianDraft, durationSeconds);

  async function copyToClipboard(text: string) {
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      // Clipboard API can fail without permission/secure context — fail silently,
      // the text remains visible and selectable regardless.
    }
  }

  function getActiveTextAndRef(): {
    text: string;
    ref: React.RefObject<HTMLTextAreaElement>;
  } {
    return activePanel === 'fa'
      ? { text: persianDraft, ref: persianRef }
      : { text: englishDraft, ref: englishRef };
  }

  function findMatchOffsets(text: string, term: string): number[] {
    if (!term.trim()) return [];
    const offsets: number[] = [];
    const lower = text.toLowerCase();
    const lowerTerm = term.toLowerCase();
    let from = 0;
    while (from <= lower.length) {
      const idx = lower.indexOf(lowerTerm, from);
      if (idx === -1) break;
      offsets.push(idx);
      from = idx + lowerTerm.length;
    }
    return offsets;
  }

  function jumpToMatch(direction: 1 | -1) {
    const { text, ref } = getActiveTextAndRef();
    const offsets = findMatchOffsets(text, searchTerm);
    if (offsets.length === 0) return;
    const nextIndex = (matchIndex + direction + offsets.length) % offsets.length;
    setMatchIndex(nextIndex);
    const start = offsets[nextIndex];
    const end = start + searchTerm.length;
    const el = ref.current;
    if (el) {
      el.focus();
      el.setSelectionRange(start, end);
    }
  }

  const activeMatches = findMatchOffsets(
    activePanel === 'fa' ? persianDraft : englishDraft,
    searchTerm
  );

  return (
    <div className="rounded-xl border border-line bg-canvas-raised">
      {/* Mobile tab switcher */}
      <div className="flex border-b border-line sm:hidden">
        <button
          type="button"
          onClick={() => setActivePanel('fa')}
          className={`flex-1 py-3 text-sm font-medium transition-colors ${
            activePanel === 'fa' ? 'text-accent border-b-2 border-accent' : 'text-ink-muted'
          }`}
        >
          فارسی
        </button>
        <button
          type="button"
          onClick={() => setActivePanel('en')}
          className={`flex-1 py-3 text-sm font-medium transition-colors ${
            activePanel === 'en' ? 'text-accent border-b-2 border-accent' : 'text-ink-muted'
          }`}
        >
          English
        </button>
      </div>

      {/* Toolbar */}
      <div className="flex flex-wrap items-center gap-2 border-b border-line px-3 py-2">
        <div className="flex items-center gap-1.5 text-ink-faint">
          <Search size={14} />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => {
              setSearchTerm(e.target.value);
              setMatchIndex(0);
            }}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                e.preventDefault();
                jumpToMatch(e.shiftKey ? -1 : 1);
              }
            }}
            placeholder="جستجو در متن..."
            className="w-32 bg-transparent text-xs text-ink placeholder:text-ink-faint focus:outline-none sm:w-44"
          />
          {searchTerm.trim() && (
            <div className="flex items-center gap-0.5 shrink-0">
              <span className="text-[11px] tabular-nums">
                {activeMatches.length > 0 ? `${matchIndex + 1}/${activeMatches.length}` : '۰'}
              </span>
              <button
                type="button"
                onClick={() => jumpToMatch(-1)}
                disabled={activeMatches.length === 0}
                aria-label="نتیجه قبلی"
                className="rounded p-0.5 hover:bg-canvas-overlay disabled:opacity-30"
              >
                <ChevronUp size={13} />
              </button>
              <button
                type="button"
                onClick={() => jumpToMatch(1)}
                disabled={activeMatches.length === 0}
                aria-label="نتیجه بعدی"
                className="rounded p-0.5 hover:bg-canvas-overlay disabled:opacity-30"
              >
                <ChevronDown size={13} />
              </button>
            </div>
          )}
        </div>
        <div className="mr-auto flex items-center gap-1.5">
          <button
            type="button"
            onClick={() => copyToClipboard(activePanel === 'fa' ? persianDraft : englishDraft)}
            className="flex h-8 w-8 items-center justify-center rounded-lg text-ink-muted hover:bg-canvas-overlay hover:text-ink"
            aria-label="کپی متن"
          >
            <Copy size={15} />
          </button>
          <button
            type="button"
            onClick={onTranslateAll}
            disabled={isTranslating || blocks.length === 0}
            className="flex items-center gap-1.5 rounded-lg bg-accent/15 px-3 py-1.5 text-xs font-medium text-accent transition-colors hover:bg-accent/25 disabled:opacity-40"
          >
            {isTranslating ? (
              <Loader2 size={14} className="animate-spin" />
            ) : (
              <Languages size={14} />
            )}
            ترجمه به انگلیسی
          </button>
        </div>
      </div>

      {!translationConfigured && (
        <div className="border-b border-line bg-signal-amber/10 px-3 py-2 text-xs text-signal-amber">
          سرویس ترجمه پیکربندی نشده است. متن فارسی به‌طور کامل در دسترس است، اما ترجمه فعال
          نیست.
        </div>
      )}

      {/* Panels */}
      <div className="grid gap-0 sm:grid-cols-2">
        <div
          className={`${activePanel === 'fa' ? 'block' : 'hidden'} sm:block sm:border-l sm:border-line`}
        >
          <div className="border-b border-line px-3 py-1.5 text-[11px] font-medium uppercase tracking-wide text-ink-faint hidden sm:block">
            متن فارسی
          </div>
          <textarea
            ref={persianRef}
            dir="rtl"
            lang="fa"
            value={persianDraft}
            onChange={(e) => setPersianDraft(e.target.value)}
            onBlur={() => {
              if (persianDraft !== derivedPersianText) onCommitPersian(persianDraft);
            }}
            placeholder="متن رونویسی‌شده اینجا نمایش داده می‌شود..."
            className="h-48 w-full resize-none bg-transparent p-3 font-fa text-[15px] leading-7 text-ink placeholder:text-ink-faint focus:outline-none"
          />
        </div>
        <div className={`${activePanel === 'en' ? 'block' : 'hidden'} sm:block`}>
          <div className="border-b border-line px-3 py-1.5 text-[11px] font-medium uppercase tracking-wide text-ink-faint hidden sm:block">
            English Translation
          </div>
          <textarea
            ref={englishRef}
            dir="ltr"
            lang="en"
            value={englishDraft}
            onChange={(e) => setEnglishDraft(e.target.value)}
            onBlur={() => {
              if (englishDraft !== derivedEnglishText) onCommitEnglish(englishDraft);
            }}
            placeholder="Translation will appear here..."
            className="h-48 w-full resize-none bg-transparent p-3 font-en text-[15px] leading-7 text-ink placeholder:text-ink-faint focus:outline-none"
          />
        </div>
      </div>

      {/* Stats bar */}
      <div className="flex flex-wrap gap-x-4 gap-y-1 border-t border-line px-3 py-2 text-[11px] text-ink-faint">
        <span>کلمات: {stats.wordCount}</span>
        <span>نویسه‌ها: {stats.characterCount}</span>
        <span>جملات: {stats.sentenceCount}</span>
      </div>
    </div>
  );
}
