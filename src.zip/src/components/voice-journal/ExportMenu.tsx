import { useState, useRef, useEffect } from 'react';
import { Download, FileText, FileSpreadsheet, File } from 'lucide-react';
import type { ExportFormat } from '@/services/export/exportSession';

interface ExportMenuProps {
  onExport: (format: ExportFormat) => void;
  disabled: boolean;
}

const OPTIONS: { format: ExportFormat; label: string; icon: typeof FileText }[] = [
  { format: 'txt', label: 'متن ساده (.txt)', icon: FileText },
  { format: 'md', label: 'مارک‌داون (.md)', icon: FileText },
  { format: 'docx', label: 'سند Word (.docx)', icon: File },
  { format: 'xlsx', label: 'صفحه‌گسترده Excel (.xlsx)', icon: FileSpreadsheet },
];

export function ExportMenu({ onExport, disabled }: ExportMenuProps) {
  const [open, setOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div className="relative" ref={menuRef}>
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        disabled={disabled}
        aria-haspopup="menu"
        aria-expanded={open}
        className="flex items-center gap-1.5 rounded-lg border border-line px-3 py-1.5 text-xs font-medium text-ink-muted transition-colors hover:border-accent/40 hover:text-ink disabled:opacity-40"
      >
        <Download size={14} />
        خروجی
      </button>
      {open && (
        <div
          role="menu"
          className="absolute left-0 top-full z-10 mt-1.5 w-52 overflow-hidden rounded-lg border border-line bg-canvas-overlay shadow-xl animate-fade-up"
        >
          {OPTIONS.map(({ format, label, icon: Icon }) => (
            <button
              key={format}
              type="button"
              role="menuitem"
              onClick={() => {
                onExport(format);
                setOpen(false);
              }}
              className="flex w-full items-center gap-2.5 px-3 py-2.5 text-right text-sm text-ink hover:bg-canvas-raised"
            >
              <Icon size={15} className="text-ink-faint" />
              {label}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
