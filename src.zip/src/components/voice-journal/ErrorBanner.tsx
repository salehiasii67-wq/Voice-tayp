import { AlertTriangle, X } from 'lucide-react';
import type { VoiceRecognitionError } from '@/types/voice-journal';

interface ErrorBannerProps {
  error: VoiceRecognitionError;
  onDismiss: () => void;
}

export function ErrorBanner({ error, onDismiss }: ErrorBannerProps) {
  return (
    <div
      role="alert"
      className="flex items-start gap-2.5 rounded-lg border border-signal-sell/30 bg-signal-sell/10 px-3 py-2.5 text-sm text-signal-sell animate-fade-up"
    >
      <AlertTriangle size={16} className="mt-0.5 shrink-0" />
      <p className="flex-1 font-fa leading-6">{error.message}</p>
      <button
        type="button"
        onClick={onDismiss}
        aria-label="بستن پیام خطا"
        className="shrink-0 rounded p-0.5 hover:bg-signal-sell/15"
      >
        <X size={15} />
      </button>
    </div>
  );
}
