import { useEffect, useState } from 'react';
import { Trash2, FolderOpen, Search } from 'lucide-react';
import type { VoiceJournalSession } from '@/types/voice-journal';
import { voiceJournalRepository } from '@/db/voiceJournalRepository';

interface SessionsPanelProps {
  onOpen: (id: string) => void;
  refreshKey: number;
}

export function SessionsPanel({ onOpen, refreshKey }: SessionsPanelProps) {
  const [sessions, setSessions] = useState<VoiceJournalSession[]>([]);
  const [query, setQuery] = useState('');

  useEffect(() => {
    let cancelled = false;
    async function load() {
      const results = query.trim()
        ? await voiceJournalRepository.search(query)
        : await voiceJournalRepository.listAll();
      if (!cancelled) setSessions(results);
    }
    load();
    return () => {
      cancelled = true;
    };
  }, [query, refreshKey]);

  async function handleDelete(
    id: string,
    e: React.MouseEvent | React.KeyboardEvent
  ) {
    e.stopPropagation();
    await voiceJournalRepository.delete(id);
    setSessions((prev) => prev.filter((s) => s.id !== id));
  }

  return (
    <div className="rounded-xl border border-line bg-canvas-raised">
      <div className="flex items-center gap-1.5 border-b border-line px-3 py-2 text-ink-faint">
        <Search size={14} />
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="جستجوی جلسات..."
          className="w-full bg-transparent text-xs text-ink placeholder:text-ink-faint focus:outline-none"
        />
      </div>
      <div className="max-h-72 overflow-y-auto">
        {sessions.length === 0 ? (
          <p className="px-3 py-6 text-center text-xs text-ink-faint">
            هنوز جلسه‌ای ذخیره نشده است.
          </p>
        ) : (
          sessions.map((s) => (
            <button
              key={s.id}
              type="button"
              onClick={() => onOpen(s.id)}
              className="flex w-full items-center gap-2 border-b border-line/60 px-3 py-2.5 text-right last:border-0 hover:bg-canvas-overlay"
            >
              <FolderOpen size={14} className="shrink-0 text-ink-faint" />
              <span className="flex-1 truncate text-sm text-ink">{s.title}</span>
              <span className="shrink-0 text-[11px] text-ink-faint">
                {new Date(s.updatedAt).toLocaleDateString('fa-IR')}
              </span>
              <span
                role="button"
                tabIndex={0}
                onClick={(e) => handleDelete(s.id, e)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleDelete(s.id, e);
                }}
                aria-label={`حذف ${s.title}`}
                className="shrink-0 rounded p-1 text-ink-faint hover:bg-signal-sell/15 hover:text-signal-sell"
              >
                <Trash2 size={13} />
              </span>
            </button>
          ))
        )}
      </div>
    </div>
  );
}
