import { useState } from 'react';
import { Save, Mic } from 'lucide-react';
import { useSpeechRecognition } from '@/hooks/useSpeechRecognition';
import { useVoiceJournalStore } from '@/hooks/useVoiceJournalStore';
import { RecordingControls } from './RecordingControls';
import { LiveTranscript } from './LiveTranscript';
import { BilingualEditor } from './BilingualEditor';
import { ErrorBanner } from './ErrorBanner';
import { ExportMenu } from './ExportMenu';
import { SessionsPanel } from './SessionsPanel';
import { exportSession, type ExportFormat } from '@/services/export/exportSession';
import {
  matchVoiceActionCommand,
  dispatchVoiceAction,
  type VoiceActionHandlers,
} from '@/utils/voiceActionCommands';

export function VoiceJournal() {
  const [refreshKey, setRefreshKey] = useState(0);
  const [saveConfirmation, setSaveConfirmation] = useState(false);

  const store = useVoiceJournalStore();

  const speech = useSpeechRecognition({
    language: 'fa-IR',
    onFinalChunk: (text) => {
      const command = matchVoiceActionCommand(text);
      if (command) {
        const handlers: VoiceActionHandlers = {
          'save-journal': () => handleSave(),
          translate: () => store.translateAll(),
          'clear-text': () => {
            speech.clear();
            store.clearSession();
          },
          'stop-recording': () => speech.stop(),
        };
        dispatchVoiceAction(command, handlers);
        return;
      }
      store.addFinalChunk(text);
    },
  });

  // Extension point for future structured voice input (§12 of the spec):
  // a command-processing layer could inspect speech.finalText here to
  // extract structured fields (symbol, direction, risk %, result) once a
  // secure AI backend is available. Intentionally not implemented yet.

  async function handleSave() {
    const id = await store.saveSession(speech.durationSeconds);
    setSaveConfirmation(true);
    setRefreshKey((k) => k + 1);
    setTimeout(() => setSaveConfirmation(false), 2000);
    return id;
  }

  async function handleOpenSession(id: string) {
    speech.stop();
    speech.clear();
    await store.loadSession(id);
  }

  async function handleExport(format: ExportFormat) {
    const persianText = store.blocks.map((b) => b.persianText).join(' ');
    const englishText = store.blocks.map((b) => b.englishText ?? '').join(' ').trim();
    await exportSession(
      {
        id: store.currentSessionId ?? 'draft',
        title: store.title || 'ژورنال صوتی',
        persianText,
        englishText,
        blocks: store.blocks,
        createdAt: Date.now(),
        updatedAt: Date.now(),
        duration: speech.durationSeconds,
        wordCount: persianText.trim() ? persianText.trim().split(/\s+/).length : 0,
        language: 'fa-IR',
        translationStatus: 'none',
        tags: store.tags,
        notes: store.notes,
      },
      format
    );
  }

  const hasContent = store.blocks.length > 0 || speech.finalText.length > 0;

  return (
    <div className="mx-auto flex max-w-5xl flex-col gap-4 p-4 sm:p-6" dir="rtl">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-accent/15 text-accent">
            <Mic size={18} />
          </div>
          <div>
            <h1 className="font-fa text-lg font-semibold text-ink">ژورنال صوتی</h1>
            <p className="text-xs text-ink-faint">مرور روزانه معاملات با صدای شما</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <ExportMenu onExport={handleExport} disabled={!hasContent} />
          <button
            type="button"
            onClick={handleSave}
            disabled={!hasContent || store.isSaving}
            className="flex items-center gap-1.5 rounded-lg bg-accent px-3.5 py-1.5 text-xs font-semibold text-canvas transition-colors hover:bg-accent/90 disabled:opacity-40"
          >
            <Save size={14} />
            {saveConfirmation ? 'ذخیره شد' : 'ذخیره'}
          </button>
        </div>
      </div>

      {/* Title input */}
      <input
        type="text"
        value={store.title}
        onChange={(e) => store.setTitle(e.target.value)}
        placeholder="عنوان جلسه (مثلاً: مرور معاملات امروز)"
        className="rounded-lg border border-line bg-canvas-raised px-3 py-2 font-fa text-sm text-ink placeholder:text-ink-faint focus:border-accent/50 focus:outline-none"
      />

      {!speech.isSupported && (
        <ErrorBanner
          error={{
            code: 'not-supported',
            message:
              'مرورگر شما از تشخیص گفتار پشتیبانی نمی‌کند. لطفاً از آخرین نسخه Chrome یا Edge استفاده کنید.',
          }}
          onDismiss={() => {}}
        />
      )}
      {speech.error && (
        <ErrorBanner error={speech.error} onDismiss={() => {}} />
      )}

      {/* Recording controls */}
      <div className="rounded-xl border border-line bg-canvas-raised p-4">
        <RecordingControls
          state={speech.state}
          durationSeconds={speech.durationSeconds}
          onStart={speech.start}
          onPause={speech.pause}
          onResume={speech.resume}
          onStop={speech.stop}
          onClear={() => {
            speech.clear();
            store.clearSession();
          }}
        />
      </div>

      {/* Live transcript */}
      <LiveTranscript
        finalText={speech.finalText}
        interimText={speech.interimText}
        isListening={speech.state === 'listening'}
        emptyHint="برای شروع، روی دکمه میکروفون بزنید و شروع به صحبت کنید..."
      />

      {/* Bilingual editor */}
      <BilingualEditor
        blocks={store.blocks}
        onCommitPersian={store.commitPersianEdit}
        onCommitEnglish={store.commitEnglishEdit}
        onTranslateAll={store.translateAll}
        isTranslating={store.isTranslating}
        translationConfigured={store.translationConfigured}
        durationSeconds={speech.durationSeconds}
      />

      {/* Saved sessions */}
      <SessionsPanel onOpen={handleOpenSession} refreshKey={refreshKey} />
    </div>
  );
}
