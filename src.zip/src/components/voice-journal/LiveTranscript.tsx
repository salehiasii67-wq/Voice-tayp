import { useEffect, useRef, useState } from 'react';

interface LiveTranscriptProps {
  finalText: string;
  interimText: string;
  isListening: boolean;
  emptyHint: string;
}

/**
 * Renders finalized text as permanent, and interim text as a lighter,
 * trailing fragment with a blinking caret — the "live captions" feel.
 *
 * Auto-scroll behavior: scrolls to bottom on new content, but if the user
 * has manually scrolled up (reading earlier text), we detect that and
 * suspend auto-scroll until they scroll back down themselves — so we never
 * yank their reading position away.
 */
export function LiveTranscript({
  finalText,
  interimText,
  isListening,
  emptyHint,
}: LiveTranscriptProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [userScrolledUp, setUserScrolledUp] = useState(false);

  useEffect(() => {
    const el = containerRef.current;
    if (!el || userScrolledUp) return;
    el.scrollTop = el.scrollHeight;
  }, [finalText, interimText, userScrolledUp]);

  function handleScroll() {
    const el = containerRef.current;
    if (!el) return;
    const distanceFromBottom = el.scrollHeight - el.scrollTop - el.clientHeight;
    setUserScrolledUp(distanceFromBottom > 40);
  }

  const isEmpty = !finalText && !interimText;

  return (
    <div
      ref={containerRef}
      onScroll={handleScroll}
      dir="rtl"
      lang="fa"
      className="h-56 overflow-y-auto rounded-xl border border-line bg-canvas-raised p-4 font-fa text-[17px] leading-8 text-ink sm:h-64"
      role="log"
      aria-live="polite"
      aria-label="متن رونویسی زنده فارسی"
    >
      {isEmpty ? (
        <p className="text-ink-faint">{emptyHint}</p>
      ) : (
        <p className="whitespace-pre-wrap">
          {finalText}
          {interimText && (
            <span className="text-ink-muted">
              {finalText ? ' ' : ''}
              {interimText}
            </span>
          )}
          {isListening && (
            <span
              className="mr-0.5 inline-block h-5 w-[2px] translate-y-1 bg-signal-live animate-caret-blink"
              aria-hidden="true"
            />
          )}
        </p>
      )}
    </div>
  );
}
