import { Mic, Pause, Play, Square, Trash2 } from 'lucide-react';
import type { RecordingState } from '@/types/voice-journal';
import { formatDuration } from '@/utils/textStatistics';

interface RecordingControlsProps {
  state: RecordingState;
  durationSeconds: number;
  onStart: () => void;
  onPause: () => void;
  onResume: () => void;
  onStop: () => void;
  onClear: () => void;
}

const STATE_LABEL: Record<RecordingState, string> = {
  idle: 'آماده',
  listening: 'در حال شنیدن...',
  paused: 'مکث شده',
  processing: 'در حال پردازش...',
  error: 'خطا',
};

const STATE_COLOR: Record<RecordingState, string> = {
  idle: 'text-ink-muted',
  listening: 'text-signal-live',
  paused: 'text-signal-amber',
  processing: 'text-signal-amber',
  error: 'text-signal-sell',
};

export function RecordingControls({
  state,
  durationSeconds,
  onStart,
  onPause,
  onResume,
  onStop,
  onClear,
}: RecordingControlsProps) {
  const isListening = state === 'listening';
  const isPaused = state === 'paused';
  const isIdle = state === 'idle';

  return (
    <div className="flex flex-col gap-3">
      <div className="flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          {/* Mic / Start-Stop */}
          <button
            type="button"
            onClick={isIdle ? onStart : onStop}
            aria-label={isIdle ? 'شروع ضبط' : 'توقف ضبط'}
            className={`relative flex h-14 w-14 items-center justify-center rounded-full transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent ${
              isListening
                ? 'bg-signal-sell/15 text-signal-sell'
                : 'bg-accent/15 text-accent hover:bg-accent/25'
            }`}
          >
            {isListening && (
              <span
                className="absolute inset-0 rounded-full bg-signal-live/40 animate-pulse-ring"
                aria-hidden="true"
              />
            )}
            {isIdle ? <Mic size={22} /> : <Square size={20} />}
          </button>

          {/* Pause / Resume */}
          <button
            type="button"
            onClick={isPaused ? onResume : onPause}
            disabled={isIdle}
            aria-label={isPaused ? 'ادامه ضبط' : 'مکث ضبط'}
            className="flex h-11 w-11 items-center justify-center rounded-full bg-canvas-overlay text-ink-muted transition-colors hover:text-ink disabled:opacity-30 disabled:hover:text-ink-muted focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent"
          >
            {isPaused ? <Play size={18} /> : <Pause size={18} />}
          </button>

          {/* Clear */}
          <button
            type="button"
            onClick={onClear}
            aria-label="پاک کردن متن"
            className="flex h-11 w-11 items-center justify-center rounded-full bg-canvas-overlay text-ink-muted transition-colors hover:text-signal-sell focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent"
          >
            <Trash2 size={17} />
          </button>
        </div>

        <div className="text-left font-mono text-sm text-ink-muted" dir="ltr">
          {formatDuration(durationSeconds)}
        </div>
      </div>

      <div className="flex items-center gap-2 font-fa text-sm">
        <span
          className={`h-1.5 w-1.5 rounded-full ${
            isListening ? 'bg-signal-live' : 'bg-current'
          } ${STATE_COLOR[state]}`}
          aria-hidden="true"
        />
        <span className={STATE_COLOR[state]} role="status" aria-live="polite">
          {STATE_LABEL[state]}
        </span>
      </div>
    </div>
  );
}
