import { create } from 'zustand';
import type { TranscriptBlock, VoiceJournalSession } from '@/types/voice-journal';
import { voiceJournalRepository } from '@/db/voiceJournalRepository';
import { createTranslationService } from '@/services/translation/TranslationService';
import { translatePendingBlocks } from '@/services/translation/segmentedTranslate';
import { computeTextStatistics } from '@/utils/textStatistics';

const translationService = createTranslationService();

function generateId(): string {
  return `vjs-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
}

function blockId(): string {
  return `blk-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
}

interface VoiceJournalStoreState {
  currentSessionId: string | null;
  title: string;
  blocks: TranscriptBlock[];
  notes: string;
  tags: string[];
  isSaving: boolean;
  isTranslating: boolean;
  translationConfigured: boolean;

  addFinalChunk: (text: string) => void;
  setTitle: (title: string) => void;
  setNotes: (notes: string) => void;
  commitPersianEdit: (fullText: string) => void;
  commitEnglishEdit: (fullText: string) => void;
  clearSession: () => void;
  translateAll: () => Promise<void>;
  saveSession: (durationSeconds: number) => Promise<string>;
  loadSession: (id: string) => Promise<void>;
}

export const useVoiceJournalStore = create<VoiceJournalStoreState>((set, get) => ({
  currentSessionId: null,
  title: '',
  blocks: [],
  notes: '',
  tags: [],
  isSaving: false,
  isTranslating: false,
  translationConfigured: translationService.isConfigured,

  addFinalChunk: (text: string) => {
    if (!text.trim()) return;
    set((s) => ({
      blocks: [
        ...s.blocks,
        {
          id: blockId(),
          persianText: text,
          englishText: null,
          translationStatus: 'none',
          createdAt: Date.now(),
        },
      ],
    }));
  },

  setTitle: (title) => set({ title }),
  setNotes: (notes) => set({ notes }),

  commitPersianEdit: (fullText: string) =>
    set((s) => {
      // A manual edit to the flat Persian text invalidates the existing
      // sentence-level block segmentation (the user may have merged,
      // split, or rewritten sentences) — collapse to one block holding
      // the edited text rather than guessing a new per-line mapping.
      // Existing English translations are kept as a separate block only
      // when the Persian text actually changed; otherwise this is a no-op.
      if (fullText === s.blocks.map((b) => b.persianText).join('\n')) return s;
      const priorEnglish = s.blocks
        .map((b) => b.englishText ?? '')
        .join(' ')
        .trim();
      return {
        blocks: [
          {
            id: blockId(),
            persianText: fullText,
            englishText: priorEnglish || null,
            translationStatus: 'none' as const,
            createdAt: Date.now(),
          },
        ],
      };
    }),

  commitEnglishEdit: (fullText: string) =>
    set((s) => {
      const priorPersian = s.blocks.map((b) => b.persianText).join('\n');
      return {
        blocks: [
          {
            id: blockId(),
            persianText: priorPersian,
            englishText: fullText,
            translationStatus: 'complete' as const,
            createdAt: Date.now(),
          },
        ],
      };
    }),

  clearSession: () =>
    set({
      currentSessionId: null,
      title: '',
      blocks: [],
      notes: '',
      tags: [],
    }),

  translateAll: async () => {
    set({ isTranslating: true });
    const updated = await translatePendingBlocks(get().blocks, translationService);
    set({ blocks: updated, isTranslating: false });
  },

  saveSession: async (durationSeconds: number) => {
    set({ isSaving: true });
    const s = get();
    const persianText = s.blocks.map((b) => b.persianText).join(' ');
    const englishText = s.blocks.map((b) => b.englishText ?? '').join(' ').trim();
    const stats = computeTextStatistics(persianText, durationSeconds);

    const id = s.currentSessionId ?? generateId();
    const now = Date.now();
    const existing = s.currentSessionId
      ? await voiceJournalRepository.getById(s.currentSessionId)
      : undefined;

    const session: VoiceJournalSession = {
      id,
      title: s.title.trim() || `ژورنال صوتی — ${new Date(now).toLocaleDateString('fa-IR')}`,
      persianText,
      englishText,
      blocks: s.blocks,
      createdAt: existing?.createdAt ?? now,
      updatedAt: now,
      duration: durationSeconds,
      wordCount: stats.wordCount,
      language: 'fa-IR',
      translationStatus:
        s.blocks.length === 0
          ? 'none'
          : s.blocks.every((b) => b.translationStatus === 'complete')
          ? 'complete'
          : s.blocks.some((b) => b.translationStatus === 'complete')
          ? 'partial'
          : 'none',
      tags: s.tags,
      notes: s.notes,
    };

    if (existing) {
      await voiceJournalRepository.update(id, session);
    } else {
      await voiceJournalRepository.create(session);
    }

    set({ currentSessionId: id, isSaving: false });
    return id;
  },

  loadSession: async (id: string) => {
    const session = await voiceJournalRepository.getById(id);
    if (!session) return;
    set({
      currentSessionId: session.id,
      title: session.title,
      blocks: session.blocks,
      notes: session.notes,
      tags: session.tags,
    });
  },
}));
