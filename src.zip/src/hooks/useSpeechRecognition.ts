import { useCallback, useEffect, useRef, useState } from 'react';
import { BrowserSpeechProvider } from '@/services/speech/BrowserSpeechProvider';
import type {
  SpeechRecognitionProvider,
  ProviderState,
} from '@/services/speech/SpeechRecognitionProvider';
import type {
  RecordingState,
  TranscriptSegment,
  VoiceRecognitionError,
} from '@/types/voice-journal';
import { parseVoiceCommands } from '@/utils/persianVoiceCommands';

interface UseSpeechRecognitionOptions {
  language?: string;
  /** Called with each finalized, punctuation-parsed sentence-level chunk. */
  onFinalChunk?: (text: string) => void;
}

interface UseSpeechRecognitionResult {
  state: RecordingState;
  /** Accumulated, finalized transcript text (punctuation commands already applied). */
  finalText: string;
  /** Current in-progress (not yet final) text — render this in a lighter style. */
  interimText: string;
  error: VoiceRecognitionError | null;
  isSupported: boolean;
  start: () => void;
  pause: () => void;
  resume: () => void;
  stop: () => void;
  clear: () => void;
  /** Recording duration in seconds, accumulated across pause/resume cycles. */
  durationSeconds: number;
}

/**
 * useSpeechRecognition
 * ---------------------
 * Owns the accumulated transcript. This is the one piece of state that
 * must never duplicate or drop text across interim→final transitions or
 * pause/resume cycles (requirement: "extremely important" in the spec).
 *
 * Strategy:
 * - `finalText` only ever grows by appending newly-finalized segments.
 *   It is never rebuilt from scratch, so a browser-triggered session
 *   restart (see BrowserSpeechProvider) can't cause a rollback or replay.
 * - `interimText` is fully replaced on every interim segment (it reflects
 *   "what the engine currently thinks you're saying right now") and is
 *   cleared the moment its content becomes final.
 * - Each provider session starts its result indices back at 0, so we key
 *   interim replacement by "most recent interim segment", not by index,
 *   to avoid cross-session index collisions.
 */
export function useSpeechRecognition(
  options: UseSpeechRecognitionOptions = {}
): UseSpeechRecognitionResult {
  const { language = 'fa-IR', onFinalChunk } = options;

  const providerRef = useRef<SpeechRecognitionProvider | null>(null);
  const [state, setState] = useState<RecordingState>('idle');
  const [finalText, setFinalText] = useState('');
  const [interimText, setInterimText] = useState('');
  const [error, setError] = useState<VoiceRecognitionError | null>(null);
  const [isSupported, setIsSupported] = useState(true);

  const durationStartRef = useRef<number | null>(null);
  const accumulatedDurationRef = useRef(0);
  const [durationSeconds, setDurationSeconds] = useState(0);

  // Initialize provider once.
  useEffect(() => {
    const provider = new BrowserSpeechProvider();
    providerRef.current = provider;
    setIsSupported(provider.isSupported);

    provider.onStateChange((providerState: ProviderState) => {
      setState(providerState as RecordingState);
    });

    provider.onError((err) => {
      setError(err);
    });

    provider.onSegment((segment: TranscriptSegment) => {
      if (segment.isFinal) {
        const parsed = parseVoiceCommands(segment.text);
        setFinalText((prev) => {
          const needsSpace = prev.length > 0 && !prev.endsWith('\n') && parsed.length > 0;
          return prev + (needsSpace ? ' ' : '') + parsed;
        });
        setInterimText('');
        onFinalChunk?.(parsed);
      } else {
        setInterimText(segment.text);
      }
    });

    return () => {
      provider.destroy();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Duration tracking, ticking only while actively listening.
  useEffect(() => {
    if (state !== 'listening') return;
    durationStartRef.current = Date.now();
    const interval = setInterval(() => {
      if (durationStartRef.current === null) return;
      const elapsed = (Date.now() - durationStartRef.current) / 1000;
      setDurationSeconds(accumulatedDurationRef.current + elapsed);
    }, 500);
    return () => {
      clearInterval(interval);
      if (durationStartRef.current !== null) {
        accumulatedDurationRef.current += (Date.now() - durationStartRef.current) / 1000;
        durationStartRef.current = null;
      }
    };
  }, [state]);

  const start = useCallback(() => {
    setError(null);
    providerRef.current?.start({
      language,
      continuous: true,
      interimResults: true,
    });
  }, [language]);

  const pause = useCallback(() => {
    providerRef.current?.pause();
  }, []);

  const resume = useCallback(() => {
    setError(null);
    providerRef.current?.resume();
  }, []);

  const stop = useCallback(() => {
    providerRef.current?.stop();
  }, []);

  const clear = useCallback(() => {
    setFinalText('');
    setInterimText('');
    accumulatedDurationRef.current = 0;
    setDurationSeconds(0);
  }, []);

  return {
    state,
    finalText,
    interimText,
    error,
    isSupported,
    start,
    pause,
    resume,
    stop,
    clear,
    durationSeconds,
  };
}
