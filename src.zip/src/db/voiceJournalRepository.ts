import { db } from './schema';
import type { VoiceJournalSession } from '@/types/voice-journal';

/**
 * Repository for VoiceJournalSession, following the Repository Pattern
 * used elsewhere in TraderMind OS. Components/hooks should go through
 * this module rather than importing `db` directly — that's what keeps
 * the storage engine swappable and testable.
 */
export const voiceJournalRepository = {
  async create(session: VoiceJournalSession): Promise<string> {
    await db.voiceJournalSessions.add(session);
    return session.id;
  },

  async update(id: string, changes: Partial<VoiceJournalSession>): Promise<void> {
    await db.voiceJournalSessions.update(id, { ...changes, updatedAt: Date.now() });
  },

  async rename(id: string, title: string): Promise<void> {
    await db.voiceJournalSessions.update(id, { title, updatedAt: Date.now() });
  },

  async delete(id: string): Promise<void> {
    await db.voiceJournalSessions.delete(id);
  },

  async getById(id: string): Promise<VoiceJournalSession | undefined> {
    return db.voiceJournalSessions.get(id);
  },

  async listAll(): Promise<VoiceJournalSession[]> {
    return db.voiceJournalSessions.orderBy('updatedAt').reverse().toArray();
  },

  async search(query: string): Promise<VoiceJournalSession[]> {
    const normalized = query.trim().toLowerCase();
    if (!normalized) return this.listAll();
    const all = await db.voiceJournalSessions.orderBy('updatedAt').reverse().toArray();
    return all.filter(
      (s) =>
        s.title.toLowerCase().includes(normalized) ||
        s.persianText.toLowerCase().includes(normalized) ||
        s.englishText.toLowerCase().includes(normalized) ||
        s.tags.some((t) => t.toLowerCase().includes(normalized))
    );
  },

  async listByTag(tag: string): Promise<VoiceJournalSession[]> {
    return db.voiceJournalSessions.where('tags').equals(tag).toArray();
  },
};
