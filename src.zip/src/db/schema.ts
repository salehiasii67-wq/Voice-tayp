import Dexie, { type Table } from 'dexie';
import type { VoiceJournalSession } from '@/types/voice-journal';

/**
 * Standalone Dexie database for this module.
 *
 * INTEGRATION NOTE: TraderMind OS already has its own Dexie database and
 * repository layer (per project architecture notes: 17 repositories,
 * domain service layer). When wiring this into the real app:
 *   1. Add a `voiceJournalSessions` table to the existing Dexie schema
 *      instead of standing up a second database.
 *   2. Move this table definition into the app's central schema/version
 *      file so it participates in the app's existing migration chain.
 *   3. Wrap access behind a VoiceJournalRepository that follows the same
 *      Repository Pattern as the other 17 repositories, rather than
 *      calling db.voiceJournalSessions directly from components.
 * This file is written so that migration is a copy-paste of the table
 * definition plus a version bump, not a rewrite.
 */
export class VoiceJournalDatabase extends Dexie {
  voiceJournalSessions!: Table<VoiceJournalSession, string>;

  constructor() {
    super('TraderMindVoiceJournal');
    this.version(1).stores({
      // Indexed: id (PK), updatedAt (recency sort), title (search),
      // *tags (multi-entry index for tag filtering).
      voiceJournalSessions: 'id, updatedAt, title, *tags, translationStatus',
    });
  }
}

export const db = new VoiceJournalDatabase();
